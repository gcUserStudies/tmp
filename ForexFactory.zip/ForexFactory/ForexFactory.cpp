#include "sierrachart.h"
#include <string>
#include <cstring>
#include <vector>
#include <algorithm>
#include <chrono>
#include <random>

//
// 3rd Party Includes
//
#pragma region 3rd Party Includes
// JSON Parsing
// https://github.com/nlohmann/json
// Compiled against version 3.10.5
#include "nlohmann/json.hpp" 
#pragma endregion

//
// 03/21/2024 - Compiled using Sierra Chart: 2621
//

//
// Custom Study Notes
//
#pragma region Custom Study Notes
// ##################
// ### DISCLAIMER ###
// ##################
// I am learning always and self taught for programming. So while I'm airing all of my code for anyone to see also keep that in mind
// if you happen to be a real programmer :) I will gladly take any suggestions for improvement. As I have time I will also try to learn
// better ways to refactor and solve problems. So anyway, just adding this note as for anyone 'new' to programming.
// I am probably not the best example to learn from.
// 
//
// Forex Factory
// 
// Study requires compiling with nlohmann json which is an external header file
// As a result, remote builds will fail so you will need to setup a local compiler in order to build
// I'm including the json.hpp file used as I tried an updated version and it failed.
// Hopefully not violating any license issues :)
// 
// This is the 3rd iteration/re-write of this study as test of splitting design logic into three areas:
// 1. Fetching raw forex events and storing in structure
// 2. Looping through events structure and processing events to push to draw structure
// 3. FFDrawToChart function only handles drawing what is in the draw structure
//
// And also a test in organizing Inputs/Graphs/Persistent vars into enums to easily add/remove/re-order
// Learning more on C++ there are probably better ways such as namespaces/classes/etc... but for now...
//
// 05/04/2023 
// YT @VerrilloTrading / Twitter @VerrilloTrading
// Mentioned a while back in Discord that unloading study via UDP would crash Sierra
// I tried to replicate this today but unable to. Used Python to unload/re-load the studies with no crashes.
// So maybe it was an issue with previous version of Sierra? Tested with 2497.
//
// 01/29/2024
// FIXED: Bug with tomorrow's events. Logic was completely wrong lol. Updated to use AddDays function to current date for tomorrow
// 
// 01/20/2024
// ADDED: Now checks for OpenGL and uses updaed GDI functions to work properly
// TODO: Figure out StrikeOut proper length. Currently no way to use StrikeOut font. So this is a temp workaround that doesn't match the full text length
// 
// 11/01/2022
// ADDED: Option to disable logging http request data to the logs. Set to off by default. Updated messages to use 0 instead of 1 to not pop up window
// 
// 09/01/2022
// FIXED: Bug where tomorrow's events wouldn't show up if last day of month
// 
// 08/18/2022
// ADDED: Header for Today's Events so if no events or no more events for today you can still see the study is working
// ADDED: OpenGL check so if OpenGL is enabled it will provide a warning
// 
// 07/13/2022
// ADDED: Setting for Showing of Tomorrow's Events at/after a specified time
//
// 07/15/2022
// ADDED: Option to show Forecast / Previous in event title. Forgot about this previously :)
//
// 06/29/2022
// ADDED: Showing of Tomorrow's events
// ADDED: The 'All' currency to show things like G7, OPEC, etc...
//
// FIXED: Hiding events rolling off
// FIXED: All (ALL) events showing up for things like G7, OPEC, etc...
//
// BUG: Trade->Chart Trade Mode On and Region not visible, takes up same space and covers news event
//
// TODO: Look into ordering events by impact from highest to lowest when multiple at same time
// TODO: Should either UPPER or LOWER call string compares
// TODO: If two events with overlapping times/colors occur, use higher impact color
// TODO: Do we need fill space stuff anymore?
// TODO: I may not be referring to structs/etc... using the correct terminology...
// TODO: Fix crashing when removing study via UDP Interface
//
#pragma endregion

//
// Windows GDI Documentation
//
#pragma region Windows GDI Documentation
// Windows GDI documentation can be found here: 
// http://msdn.microsoft.com/en-nz/library/windows/desktop/dd145203%28v=vs.85%29.aspx

// Windows GDI font creation
// https://docs.microsoft.com/en-us/windows/win32/api/wingdi/nf-wingdi-createfonta

// Set text colors and alignment
// https://docs.microsoft.com/en-us/windows/win32/api/wingdi/nf-wingdi-settextalign
#pragma endregion

//
// Study DLL Name
//
SCDLLName("gcForexFactory")
const SCString ContactInformation = "<a href = \"https://gcuserstudies.github.io\">gcUserStudies</a>";

//
// Helper Functions
//
#pragma region Helper Functions
// Get DateTime independent of replay
SCDateTime GetNow(SCStudyInterfaceRef sc)
{
	if (sc.IsReplayRunning())
		return sc.CurrentDateTimeForReplay;
	else
		return sc.CurrentSystemDateTime;
}

// Get Tomorrow
SCDateTime GetTomorrowFromNow(SCStudyInterfaceRef sc)
{
	SCDateTime TomorrowFromNow = GetNow(sc);
	return TomorrowFromNow.AddDays(1);
}

// Generate Random Number
// https://cplusplus.com/reference/random/uniform_int_distribution/operator()/
// https://en.cppreference.com/w/cpp/numeric/random/uniform_int_distribution
int RandomInt(int min, int max)
{
	std::chrono::system_clock::rep seed = std::chrono::system_clock::now().time_since_epoch().count();
	std::default_random_engine generator(seed);

	std::uniform_int_distribution<int> distribution(min, max);
	return distribution(generator);
}

// gratefully borrowed from "Andy" @
// http://www.cplusplus.com/forum/general/48837/#msg266980
void toClipboard(HWND hwnd, const std::string& s)
{
	OpenClipboard(hwnd);
	EmptyClipboard();
	HGLOBAL hg = GlobalAlloc(GMEM_MOVEABLE, s.size() + 1);
	if (!hg)
	{
		CloseClipboard();
		return;
	}
	memcpy(GlobalLock(hg), s.c_str(), s.size() + 1);
	GlobalUnlock(hg);
	SetClipboardData(CF_TEXT, hg);
	CloseClipboard();
	GlobalFree(hg);
}

// Message Box
void OpenGLWarning(SCStudyInterfaceRef sc)
{
	s_UseTool Tool;
	Tool.Clear(); // reset tool structure for our next use
	Tool.ChartNumber = sc.ChartNumber;
	Tool.DrawingType = DRAWING_TEXT;
	Tool.Region = sc.GraphRegion;
	Tool.FontFace = sc.ChartTextFont();
	Tool.FontBold = true;
	Tool.ReverseTextColor = 0;
	Tool.Color = RGB(255, 0, 0);
	Tool.FontSize = 10;
	Tool.LineNumber = 0xDEADBEEF; // Nice one Kory!
	Tool.AddMethod = UTAM_ADD_OR_ADJUST;
	Tool.UseRelativeVerticalValues = 1;
	Tool.BeginValue = 98; // vertical % 0 - 100
	Tool.BeginDateTime = 1; // horizontal % 1-150
	Tool.DrawUnderneathMainGraph = 0; // 0 is above the main graph

	SCString msg = "";
	msg.Append("|  OpenGL Warning for Study \"%s\"\r\n");
	msg.Append("|  This study uses Windows GDI and will not\r\n");
	msg.Append("|  work properly when OpenGL is enabled\r\n");
	msg.Append("|  \r\n");
	msg.Append("|  Perform the following in Sierra Chart to resolve this issue:\r\n");
	msg.Append("|  Global Settings->Graphic Settings - Global->Other\r\n");
	msg.Append("|  Uncheck 'Use OpenGL for Chart Graphics'\r\n");
	msg.Append("|  Restart Sierra Chart\r\n");

	Tool.Text.Format(msg,
		sc.GetStudyNameUsingID(sc.StudyGraphInstanceID).GetChars()
	);

	sc.UseTool(Tool);
}
#pragma endregion

//
// Draw Functions
// 
#pragma region Draw Functions
// Forex Factory Study
void FFDrawToChart(HWND WindowHandle, HDC DeviceContext, SCStudyInterfaceRef sc);
#pragma endregion

//
// Namespaces
//
#pragma region Namespaces
// Forex Factory
namespace n_FF
{
	//
	// Global Data Structure(s)
	//
 
	// This holds events to draw
	struct FFEventToDraw
	{
		SCString EventText;
		COLORREF MarkerColor;
		COLORREF EventTextColor;
		COLORREF EventTextBackgroundColor;
		int FontWeight = 400; // 400 - regular, 700 - bold
		bool StrikeOut = false;
		bool Italic = false;
	};

	//
	// Enums to Organize sc Inputs/Graphs/Persistent Data
	//

	// SC Inputs
	enum Input
	{ ExpectedImpactHigh
	, ExpectedImpactMedium
	, ExpectedImpactLow
	, ExpectedImpactNonEconomic
	, CurrencyAUD
	, CurrencyCAD
	, CurrencyCHF
	, CurrencyCNY
	, CurrencyEUR
	, CurrencyGBP
	, CurrencyJPY
	, CurrencyNZD
	, CurrencyUSD
	, CurrencyAll
	, FontSize
	, TimeFormat
	, ExpectedImpactHighColor
	, ExpectedImpactMediumColor
	, ExpectedImpactLowColor
	, ExpectedImpactNonEconomicColor
	, EventTextColor
	, EventTextBackgroundColor
	, UpcomingEventsTextColor
	, UpcomingEventsBackgroundColor
	, CurrentEventsTextColor
	, CurrentEventsBackgroundColor
	, PastEventsTextColor
	, TomorrowEventHeaderMarkerColor
	, TomorrowEventHeaderTextColor
	, TomorrowEventHeaderBackgroundColor
	, TodaysEventsHeaderMarkerColor
	, TodaysEventsHeaderTextColor
	, TodaysEventsHeaderBackgroundColor
	, ShowTodaysEventsHeader
	, ItalicUpcomingEvents
	, BoldCurrentEvents
	, StrikeOutPastEvents
	, HidePastEvents
	, ShowTomorrowsEvents
	, ShowTomorrowsEventsStartTime
	, ShowForecastAndPrevious
	, HorizontalOffset
	, VerticalOffset
	, EventSpacingOffset
	, FillSpace
	, RegionsVisible
	, FFUpdateIntervalInMinutes
	, ShowLogMessages
	};

	// SC Subgraphs
	enum Graph
	{ UpcomingEventExpectedImpactHigh
	, UpcomingEventExpectedImpactMedium
	, UpcomingEventExpectedImpactLow
	, UpcomingEventExpectedImpactNonEconomic
	, EventHappeningRightNowExpectedImpactHigh
	, EventHappeningRightNowExpectedImpactMedium
	, EventHappeningRightNowExpectedImpactLow
	, EventHappeningRightNowExpectedImpactNonEconomic
	};

	// SC Persistent Ints
	enum p_Int
	{ UpcomingEvent
	, EventHappeningRightNow
	, RequestState
	};

	// SC Persistent Pointers
	enum p_Ptr
	{ FFEvents
	, FFEventsToDraw
	, Currencies
	, ExpectedImpact
	};

	// SC Persistent DateTime
	enum p_DateTime
	{ LastFFUpdate
	};

	// SC Persistent Strings
	enum p_Str
	{ HttpResponseContent
	};
}
#pragma endregion

//
// Custom Studies
//
#pragma region Custom Studies
/*==============================================================================
	This study loads Forex Factory events onto your chart
------------------------------------------------------------------------------*/
SCSFExport scsf_gcForexFactory(SCStudyInterfaceRef sc)
{
	// JSON Parsing
	using json = nlohmann::json;

	// Struct to hold initial raw Event Data
	struct FFEvent {
		SCString title;
		SCString country;
		SCDateTime date;
		SCString impact;
		SCString forecast;
		SCString previous;
	};

	// Track when we last updated study data from Forex Factory
	SCDateTime& LastFFUpdate = sc.GetPersistentSCDateTime(n_FF::p_DateTime::LastFFUpdate);

	// HTTP Response
	SCString& HttpResponseContent = sc.GetPersistentSCString(n_FF::p_Str::HttpResponseContent);

	// Pointer to Struct Array for Raw FF Events
	std::vector<FFEvent>* p_FFEvents = reinterpret_cast<std::vector<FFEvent>*>(sc.GetPersistentPointer(n_FF::p_Ptr::FFEvents));

	// Pointer to Struct Array for FF Events to Draw
	std::vector<n_FF::FFEventToDraw>* p_FFEventsToDraw = reinterpret_cast<std::vector<n_FF::FFEventToDraw>*>(sc.GetPersistentPointer(n_FF::p_Ptr::FFEventsToDraw));

	// Pointer to Struct Array for currencies
	std::vector<SCString>* p_Currencies = reinterpret_cast<std::vector<SCString>*>(sc.GetPersistentPointer(n_FF::p_Ptr::Currencies));

	// Pointer to Struct Array for Expected Impact Levels
	std::vector<SCString>* p_ExpectedImpact = reinterpret_cast<std::vector<SCString>*>(sc.GetPersistentPointer(n_FF::p_Ptr::ExpectedImpact));

	// Get current DateTime and H/M/S
	SCDateTime CurrentDateTime = GetNow(sc);
	int CurrentDay = CurrentDateTime.GetDay();
	int CurrentHour = CurrentDateTime.GetHour();
	int CurrentMinute = CurrentDateTime.GetMinute();

	// Get Tomorrow
	SCDateTime Tomorrow = GetTomorrowFromNow(sc);
	int TomorrowDay = Tomorrow.GetDay();

	// Generate random second
	// Idea is if many people are using this study then don't have it behave like some bot-net activity
	// with everyone hitting a request update at the exact same time interval
	// Could do more with this probably
	int RandomSecond = RandomInt(0, 29) + RandomInt(30, 59);

	if (sc.SetDefaults)
	{
		sc.GraphName = "gc: Forex Factory Events";
		SCString StudyDescription;
		StudyDescription.Format("<b>%s</b> by %s", sc.GraphName.GetChars(), ContactInformation.GetChars());
		sc.StudyDescription = StudyDescription.AppendFormat(
			"<br><br>This Study downloads Forex Factory events and displays them on your Chart"
		);
		sc.GraphRegion = 0;
		sc.AutoLoop = 0; // manual looping

#pragma region Inputs
		sc.Input[n_FF::Input::ExpectedImpactHigh].Name = "Expected Impact: High";
		sc.Input[n_FF::Input::ExpectedImpactHigh].SetDescription("Show High Impact Events");
		sc.Input[n_FF::Input::ExpectedImpactHigh].SetYesNo(1);

		sc.Input[n_FF::Input::ExpectedImpactMedium].Name = "Expected Impact: Medium";
		sc.Input[n_FF::Input::ExpectedImpactMedium].SetDescription("Show Medium Impact Events");
		sc.Input[n_FF::Input::ExpectedImpactMedium].SetYesNo(1);

		sc.Input[n_FF::Input::ExpectedImpactLow].Name = "Expected Impact: Low";
		sc.Input[n_FF::Input::ExpectedImpactLow].SetDescription("Show Low Impact Events");
		sc.Input[n_FF::Input::ExpectedImpactLow].SetYesNo(1);

		sc.Input[n_FF::Input::ExpectedImpactNonEconomic].Name = "Expected Impact: Non-Economic";
		sc.Input[n_FF::Input::ExpectedImpactNonEconomic].SetDescription("Show Non-Economic Impact Events");
		sc.Input[n_FF::Input::ExpectedImpactNonEconomic].SetYesNo(0);

		sc.Input[n_FF::Input::CurrencyAUD].Name = "Currencies - AUD";
		sc.Input[n_FF::Input::CurrencyAUD].SetDescription("Show AUD Currency Related Events");
		sc.Input[n_FF::Input::CurrencyAUD].SetYesNo(0);

		sc.Input[n_FF::Input::CurrencyCAD].Name = "Currencies - CAD";
		sc.Input[n_FF::Input::CurrencyCAD].SetDescription("Show CAD Currency Related Events");
		sc.Input[n_FF::Input::CurrencyCAD].SetYesNo(0);

		sc.Input[n_FF::Input::CurrencyCHF].Name = "Currencies - CHF";
		sc.Input[n_FF::Input::CurrencyCHF].SetDescription("Show CHF Currency Related Events");
		sc.Input[n_FF::Input::CurrencyCHF].SetYesNo(0);

		sc.Input[n_FF::Input::CurrencyCNY].Name = "Currencies - CNY";
		sc.Input[n_FF::Input::CurrencyCNY].SetDescription("Show CNY Currency Related Events");
		sc.Input[n_FF::Input::CurrencyCNY].SetYesNo(0);

		sc.Input[n_FF::Input::CurrencyEUR].Name = "Currencies - EUR";
		sc.Input[n_FF::Input::CurrencyEUR].SetDescription("Show EUR Currency Related Events");
		sc.Input[n_FF::Input::CurrencyEUR].SetYesNo(0);

		sc.Input[n_FF::Input::CurrencyGBP].Name = "Currencies - GBP";
		sc.Input[n_FF::Input::CurrencyGBP].SetDescription("Show GBP Currency Related Events");
		sc.Input[n_FF::Input::CurrencyGBP].SetYesNo(0);

		sc.Input[n_FF::Input::CurrencyJPY].Name = "Currencies - JPY";
		sc.Input[n_FF::Input::CurrencyJPY].SetDescription("Show JPY Currency Related Events");
		sc.Input[n_FF::Input::CurrencyJPY].SetYesNo(0);

		sc.Input[n_FF::Input::CurrencyNZD].Name = "Currencies - NZD";
		sc.Input[n_FF::Input::CurrencyNZD].SetDescription("Show NZD Currency Related Events");
		sc.Input[n_FF::Input::CurrencyNZD].SetYesNo(0);

		sc.Input[n_FF::Input::CurrencyUSD].Name = "Currencies - USD";
		sc.Input[n_FF::Input::CurrencyUSD].SetDescription("Show USD Currency Related Events");
		sc.Input[n_FF::Input::CurrencyUSD].SetYesNo(1);

		sc.Input[n_FF::Input::CurrencyAll].Name = "Enable Events with Category 'All' [G7, OPEC, etc..]";
		sc.Input[n_FF::Input::CurrencyAll].SetDescription("Show 'Global' Currency Related Events");
		sc.Input[n_FF::Input::CurrencyAll].SetYesNo(1);

		sc.Input[n_FF::Input::HorizontalOffset].Name = "Initial Horizontal Position From Left in px";
		sc.Input[n_FF::Input::HorizontalOffset].SetDescription("Adjust this to move events further right/left on chart");
		sc.Input[n_FF::Input::HorizontalOffset].SetInt(2);

		sc.Input[n_FF::Input::VerticalOffset].Name = "Initial Veritical Position From Top in px";
		sc.Input[n_FF::Input::VerticalOffset].SetDescription("Starting point for where events are drawn from the top of the chart. May need to be adjusted if using chart trading as it may cover up that area otherwise.");
		sc.Input[n_FF::Input::VerticalOffset].SetInt(12);

		sc.Input[n_FF::Input::FontSize].Name = "Font Size";
		sc.Input[n_FF::Input::FontSize].SetDescription("Font size used for displaying events");
		// Adjust defaults based on differences in font size when OpenGL active or not
		if (sc.IsOpenGLActive())
			sc.Input[n_FF::Input::FontSize].SetInt(0);
		else
			sc.Input[n_FF::Input::FontSize].SetInt(18);
		
		sc.Input[n_FF::Input::FontSize].SetIntLimits(0, 100);

		sc.Input[n_FF::Input::FillSpace].Name = "Fill Space for Future Events";
		sc.Input[n_FF::Input::FillSpace].SetDescription("Currently not used");
		sc.Input[n_FF::Input::FillSpace].SetInt(0);
		sc.Input[n_FF::Input::FillSpace].SetIntLimits(0, MAX_STUDY_LENGTH);

		sc.Input[n_FF::Input::EventSpacingOffset].Name = "Spacing Between Events";
		sc.Input[n_FF::Input::EventSpacingOffset].SetDescription("Adjust how much space is between each event");
		sc.Input[n_FF::Input::EventSpacingOffset].SetInt(2);
		sc.Input[n_FF::Input::EventSpacingOffset].SetIntLimits(0, 100);

		sc.Input[n_FF::Input::TimeFormat].Name = "Time Format";
		sc.Input[n_FF::Input::TimeFormat].SetDescription("Sets time to am/pm or 24 hour format");
		sc.Input[n_FF::Input::TimeFormat].SetCustomInputStrings("am / pm;24 Hour");
		sc.Input[n_FF::Input::TimeFormat].SetCustomInputIndex(0);

		sc.Input[n_FF::Input::ExpectedImpactHighColor].Name = "Expected Impact High Color";
		sc.Input[n_FF::Input::ExpectedImpactHighColor].SetDescription("Marker color used next to each event. Defaults to Forex Factory colors.");
		sc.Input[n_FF::Input::ExpectedImpactHighColor].SetColor(RGB(252, 2, 2));

		sc.Input[n_FF::Input::ExpectedImpactMediumColor].Name = "Expected Impact Medium Color";
		sc.Input[n_FF::Input::ExpectedImpactMediumColor].SetDescription("Marker color used next to each event. Defaults to Forex Factory colors.");
		sc.Input[n_FF::Input::ExpectedImpactMediumColor].SetColor(RGB(247, 152, 55));

		sc.Input[n_FF::Input::ExpectedImpactLowColor].Name = "Expected Impact Low Color";
		sc.Input[n_FF::Input::ExpectedImpactLowColor].SetDescription("Marker color used next to each event. Defaults to Forex Factory colors.");
		sc.Input[n_FF::Input::ExpectedImpactLowColor].SetColor(RGB(249, 227, 46));

		sc.Input[n_FF::Input::ExpectedImpactNonEconomicColor].Name = "Expected Impact Non-Economic Color";
		sc.Input[n_FF::Input::ExpectedImpactNonEconomicColor].SetDescription("Marker color used next to each event. Defaults to Forex Factory colors.");
		sc.Input[n_FF::Input::ExpectedImpactNonEconomicColor].SetColor(RGB(185, 186, 188));

		sc.Input[n_FF::Input::EventTextColor].Name = "Event Text Color";
		sc.Input[n_FF::Input::EventTextColor].SetDescription("Default event text color");
		sc.Input[n_FF::Input::EventTextColor].SetColor(RGB(0, 0, 0));

		sc.Input[n_FF::Input::EventTextBackgroundColor].Name = "Event Text Background Color";
		sc.Input[n_FF::Input::EventTextBackgroundColor].SetDescription("Default event text background color");
		sc.Input[n_FF::Input::EventTextBackgroundColor].SetColor(RGB(244, 246, 249));

		sc.Input[n_FF::Input::RegionsVisible].Name = "Chart->Chart Settings->Region Number 1->Visible";
		sc.Input[n_FF::Input::RegionsVisible].SetDescription("This adjust event spacing down by default. If you don't have this region visible you can change this setting to offset event spacing up to fill this region. However, if you use chart trading you may need to leave this setting so it doesn't cover up the trade position text.");
		sc.Input[n_FF::Input::RegionsVisible].SetYesNo(1);

		sc.Input[n_FF::Input::StrikeOutPastEvents].Name = "Strikeout Past Events";
		sc.Input[n_FF::Input::StrikeOutPastEvents].SetDescription("Use strikeout font for past events");
		sc.Input[n_FF::Input::StrikeOutPastEvents].SetYesNo(1);

		sc.Input[n_FF::Input::PastEventsTextColor].Name = "Past Events Text Color";
		sc.Input[n_FF::Input::PastEventsTextColor].SetDescription("Sets text color for past events");
		sc.Input[n_FF::Input::PastEventsTextColor].SetColor(RGB(127, 127, 127));

		sc.Input[n_FF::Input::ItalicUpcomingEvents].Name = "Italic Upcoming Events";
		sc.Input[n_FF::Input::ItalicUpcomingEvents].SetDescription("Use Italic fonts for upcoming events");
		sc.Input[n_FF::Input::ItalicUpcomingEvents].SetYesNo(1);

		sc.Input[n_FF::Input::UpcomingEventsTextColor].Name = "Upcoming Events Text Color";
		sc.Input[n_FF::Input::UpcomingEventsTextColor].SetDescription("Sets text color for upcoming events");
		sc.Input[n_FF::Input::UpcomingEventsTextColor].SetColor(RGB(0, 0, 0));

		sc.Input[n_FF::Input::UpcomingEventsBackgroundColor].Name = "Upcoming Events Background Color";
		sc.Input[n_FF::Input::UpcomingEventsBackgroundColor].SetDescription("Sets background color for upcoming events");
		sc.Input[n_FF::Input::UpcomingEventsBackgroundColor].SetColor(RGB(255, 255, 217));

		sc.Input[n_FF::Input::HidePastEvents].Name = "Hide Past Events";
		sc.Input[n_FF::Input::HidePastEvents].SetDescription("This removes past events from queue so they are no longer displayed. This is 1 minute after the event has occured.");
		sc.Input[n_FF::Input::HidePastEvents].SetYesNo(0);

		sc.Input[n_FF::Input::CurrentEventsTextColor].Name = "Current Events Text Color";
		sc.Input[n_FF::Input::CurrentEventsTextColor].SetDescription("Text color for the event happening at the current time");
		sc.Input[n_FF::Input::CurrentEventsTextColor].SetColor(RGB(0, 0, 0));

		sc.Input[n_FF::Input::CurrentEventsBackgroundColor].Name = "Current Events Background Color";
		sc.Input[n_FF::Input::CurrentEventsBackgroundColor].SetDescription("Text background color for the event happening at the current time");
		sc.Input[n_FF::Input::CurrentEventsBackgroundColor].SetColor(RGB(0, 255, 0));

		sc.Input[n_FF::Input::FFUpdateIntervalInMinutes].Name = "Forex Factory Event Update Interval (minutes)";
		sc.Input[n_FF::Input::FFUpdateIntervalInMinutes].SetDescription("This sets the update frequency in minutes to refresh the Forex Factory data. Lowest value allowed is 5 minutes and max value is 240 (4 hours).");
		sc.Input[n_FF::Input::FFUpdateIntervalInMinutes].SetInt(9);
		// Logic - Don't need to continually blast FF with requests, so set to 5 minutes as lowest
		sc.Input[n_FF::Input::FFUpdateIntervalInMinutes].SetIntLimits(5, 240);

		sc.Input[n_FF::Input::BoldCurrentEvents].Name = "Bold Current Events";
		sc.Input[n_FF::Input::BoldCurrentEvents].SetDescription("Use bold font for the event happening at the current time");
		sc.Input[n_FF::Input::BoldCurrentEvents].SetYesNo(1);

		sc.Input[n_FF::Input::ShowTomorrowsEvents].Name = "Show Tomorrow's Events";
		sc.Input[n_FF::Input::ShowTomorrowsEvents].SetDescription("Enable if you want to see events for tomorrow displayed");
		sc.Input[n_FF::Input::ShowTomorrowsEvents].SetYesNo(0);
		
		sc.Input[n_FF::Input::ShowTomorrowsEventsStartTime].Name = "Show Tomorrow's Events Starting at This Time";
		sc.Input[n_FF::Input::ShowTomorrowsEventsStartTime].SetDescription("You can specify the time you would like tomorrow's events to be displayed at. Example, if you want to see tomorrow's events but not until 13:00, you would set the time accordingly. Defaults to Evening Session time if that is set in your chart.");
		sc.Input[n_FF::Input::ShowTomorrowsEventsStartTime].SetTime(sc.StartTime2);
		
		sc.Input[n_FF::Input::ShowForecastAndPrevious].Name = "Include Forecast / Previous in Event Title";
		sc.Input[n_FF::Input::ShowForecastAndPrevious].SetDescription("This will show the event's Forecast and Previous values in the event title");
		sc.Input[n_FF::Input::ShowForecastAndPrevious].SetYesNo(0);
		
		sc.Input[n_FF::Input::TomorrowEventHeaderMarkerColor].Name = "Tomorrow's Event Header Marker Color";
		sc.Input[n_FF::Input::TomorrowEventHeaderMarkerColor].SetDescription("Marker color used for the header that divides today and tomorrow events");
		sc.Input[n_FF::Input::TomorrowEventHeaderMarkerColor].SetColor(RGB(100, 100, 100));
		
		sc.Input[n_FF::Input::TomorrowEventHeaderTextColor].Name = "Tomorrow's Event Header Text Color";
		sc.Input[n_FF::Input::TomorrowEventHeaderTextColor].SetDescription("Text color used for the header that divides today and tomorrow events");
		sc.Input[n_FF::Input::TomorrowEventHeaderTextColor].SetColor(RGB(255, 255, 255));
		
		sc.Input[n_FF::Input::TomorrowEventHeaderBackgroundColor].Name = "Tomorrow's Event Header Background Color";
		sc.Input[n_FF::Input::TomorrowEventHeaderBackgroundColor].SetDescription("Background color used for the header that divides today and tomorrow events");
		sc.Input[n_FF::Input::TomorrowEventHeaderBackgroundColor].SetColor(RGB(50, 50, 50));

		sc.Input[n_FF::Input::ShowTodaysEventsHeader].Name = "Show Today's Events Header";
		sc.Input[n_FF::Input::ShowTodaysEventsHeader].SetYesNo(1);
		sc.Input[n_FF::Input::ShowTodaysEventsHeader].SetDescription("Enable if you want to see header for Today's Events");

		sc.Input[n_FF::Input::TodaysEventsHeaderMarkerColor].Name = "Today's Events Header Marker Color";
		sc.Input[n_FF::Input::TodaysEventsHeaderMarkerColor].SetDescription("Marker color used for the header that displays today's events");
		sc.Input[n_FF::Input::TodaysEventsHeaderMarkerColor].SetColor(RGB(100, 100, 100));

		sc.Input[n_FF::Input::TodaysEventsHeaderTextColor].Name = "Today's Events Header Text Color";
		sc.Input[n_FF::Input::TodaysEventsHeaderTextColor].SetDescription("Text color used for the header that displays today's events");
		sc.Input[n_FF::Input::TodaysEventsHeaderTextColor].SetColor(RGB(255, 255, 255));

		sc.Input[n_FF::Input::TodaysEventsHeaderBackgroundColor].Name = "Today's Events Header Background Color";
		sc.Input[n_FF::Input::TodaysEventsHeaderBackgroundColor].SetDescription("Background color used for the header that displays today's events");
		sc.Input[n_FF::Input::TodaysEventsHeaderBackgroundColor].SetColor(RGB(50, 50, 50));

		sc.Input[n_FF::Input::ShowLogMessages].Name = "Show Log Messages";
		sc.Input[n_FF::Input::ShowLogMessages].SetDescription("Set to Yes to show debug messages");
		sc.Input[n_FF::Input::ShowLogMessages].SetYesNo(0);
		

#pragma endregion

#pragma region Subgraphs
		sc.Subgraph[n_FF::Graph::UpcomingEventExpectedImpactHigh].Name = "Upcoming Event: Impact High";
		sc.Subgraph[n_FF::Graph::UpcomingEventExpectedImpactHigh].DrawStyle = DRAWSTYLE_POINTHIGH;
		sc.Subgraph[n_FF::Graph::UpcomingEventExpectedImpactHigh].PrimaryColor = sc.Input[n_FF::Input::ExpectedImpactHighColor].GetColor();

		sc.Subgraph[n_FF::Graph::UpcomingEventExpectedImpactMedium].Name = "Upcoming Event: Impact Medium ";
		sc.Subgraph[n_FF::Graph::UpcomingEventExpectedImpactMedium].DrawStyle = DRAWSTYLE_POINTHIGH;
		sc.Subgraph[n_FF::Graph::UpcomingEventExpectedImpactMedium].PrimaryColor = sc.Input[n_FF::Input::ExpectedImpactMediumColor].GetColor();

		sc.Subgraph[n_FF::Graph::UpcomingEventExpectedImpactLow].Name = "Upcoming Event: Impact Low";
		sc.Subgraph[n_FF::Graph::UpcomingEventExpectedImpactLow].DrawStyle = DRAWSTYLE_POINTHIGH;
		sc.Subgraph[n_FF::Graph::UpcomingEventExpectedImpactLow].PrimaryColor = sc.Input[n_FF::Input::ExpectedImpactLowColor].GetColor();

		sc.Subgraph[n_FF::Graph::UpcomingEventExpectedImpactNonEconomic].Name = "Upcoming Event: Impact Non-Economic";
		sc.Subgraph[n_FF::Graph::UpcomingEventExpectedImpactNonEconomic].DrawStyle = DRAWSTYLE_POINTHIGH;
		sc.Subgraph[n_FF::Graph::UpcomingEventExpectedImpactNonEconomic].PrimaryColor = sc.Input[n_FF::Input::ExpectedImpactNonEconomicColor].GetColor();

		// TODO: Review naming semantics with EventHappeningRightNow and Current Event
		sc.Subgraph[n_FF::Graph::EventHappeningRightNowExpectedImpactHigh].Name = "Current Event: Impact High";
		sc.Subgraph[n_FF::Graph::EventHappeningRightNowExpectedImpactHigh].DrawStyle = DRAWSTYLE_COLORBARHOLLOW;
		sc.Subgraph[n_FF::Graph::EventHappeningRightNowExpectedImpactHigh].PrimaryColor = sc.Input[n_FF::Input::ExpectedImpactHighColor].GetColor();

		sc.Subgraph[n_FF::Graph::EventHappeningRightNowExpectedImpactMedium].Name = "Current Event: Impact Medium";
		sc.Subgraph[n_FF::Graph::EventHappeningRightNowExpectedImpactMedium].DrawStyle = DRAWSTYLE_COLORBARHOLLOW;
		sc.Subgraph[n_FF::Graph::EventHappeningRightNowExpectedImpactMedium].PrimaryColor = sc.Input[n_FF::Input::ExpectedImpactMediumColor].GetColor();

		sc.Subgraph[n_FF::Graph::EventHappeningRightNowExpectedImpactLow].Name = "Upcoming Event: Impact Low";
		sc.Subgraph[n_FF::Graph::EventHappeningRightNowExpectedImpactLow].DrawStyle = DRAWSTYLE_COLORBARHOLLOW;
		sc.Subgraph[n_FF::Graph::EventHappeningRightNowExpectedImpactLow].PrimaryColor = sc.Input[n_FF::Input::ExpectedImpactLowColor].GetColor();

		sc.Subgraph[n_FF::Graph::EventHappeningRightNowExpectedImpactNonEconomic].Name = "Upcoming Event: Impact Non-Economic";
		sc.Subgraph[n_FF::Graph::EventHappeningRightNowExpectedImpactNonEconomic].DrawStyle = DRAWSTYLE_COLORBARHOLLOW;
		sc.Subgraph[n_FF::Graph::EventHappeningRightNowExpectedImpactNonEconomic].PrimaryColor = sc.Input[n_FF::Input::ExpectedImpactNonEconomicColor].GetColor();
#pragma endregion

		return;
	}

	// Force fill space but don't adjust smaller if it's already set larger than required.
	// Idea here would be to flag where future events occur on the chart timeline
	// May not really be needed at this point based on how upcoming events are now flagged
	// and subgraphs exist to alert on it
	if (sc.NumFillSpaceBars < unsigned(sc.Input[n_FF::Input::FillSpace].GetInt()))
		sc.NumFillSpaceBars = sc.Input[n_FF::Input::FillSpace].GetInt();

#pragma region Event Filters
#pragma region Currency Filter
	// Array of Currencies
	if (p_Currencies == NULL)
	{
		p_Currencies = new std::vector<SCString>;
		sc.SetPersistentPointer(n_FF::p_Ptr::Currencies, p_Currencies);
	}
	else
		p_Currencies->clear();

	// This creates a filter for currencies based on user selection
	if (sc.Input[n_FF::Input::CurrencyAUD].GetYesNo())
		p_Currencies->push_back("AUD");
	if (sc.Input[n_FF::Input::CurrencyCAD].GetYesNo())
		p_Currencies->push_back("CAD");
	if (sc.Input[n_FF::Input::CurrencyCHF].GetYesNo())
		p_Currencies->push_back("CHF");
	if (sc.Input[n_FF::Input::CurrencyCNY].GetYesNo())
		p_Currencies->push_back("CNY");
	if (sc.Input[n_FF::Input::CurrencyEUR].GetYesNo())
		p_Currencies->push_back("EUR");
	if (sc.Input[n_FF::Input::CurrencyGBP].GetYesNo())
		p_Currencies->push_back("GBP");
	if (sc.Input[n_FF::Input::CurrencyJPY].GetYesNo())
		p_Currencies->push_back("JPY");
	if (sc.Input[n_FF::Input::CurrencyNZD].GetYesNo())
		p_Currencies->push_back("NZD");
	if (sc.Input[n_FF::Input::CurrencyUSD].GetYesNo())
		p_Currencies->push_back("USD");
	if (sc.Input[n_FF::Input::CurrencyAll].GetYesNo())
		p_Currencies->push_back("All"); // 8/24/2023 - Looks like this is now All vs ALL. Need to overall so it's 100% case independent
#pragma endregion

#pragma region Impact Filter
	// Array of Impacts
	if (p_ExpectedImpact == NULL)
	{
		p_ExpectedImpact = new std::vector<SCString>;
		sc.SetPersistentPointer(n_FF::p_Ptr::ExpectedImpact, p_ExpectedImpact);
	}
	else
		p_ExpectedImpact->clear();

	// This creates a filter for impact levels based on user selection
	if (sc.Input[n_FF::Input::ExpectedImpactHigh].GetYesNo())
		p_ExpectedImpact->push_back("High");
	if (sc.Input[n_FF::Input::ExpectedImpactMedium].GetYesNo())
		p_ExpectedImpact->push_back("Medium");
	if (sc.Input[n_FF::Input::ExpectedImpactLow].GetYesNo())
		p_ExpectedImpact->push_back("Low");
	if (sc.Input[n_FF::Input::ExpectedImpactNonEconomic].GetYesNo())
		p_ExpectedImpact->push_back("Holiday");
#pragma endregion
#pragma endregion

	// Array of FFEvent structs for each event
	if (p_FFEvents == NULL)
	{
		p_FFEvents = new std::vector<FFEvent>;
		sc.SetPersistentPointer(n_FF::p_Ptr::FFEvents, p_FFEvents);
	}

	// Array of FFEventToDraw structs for each event
	// TODO: Fix naming plural inconsistency
	if (p_FFEventsToDraw == NULL)
	{
		p_FFEventsToDraw = new std::vector<n_FF::FFEventToDraw>;
		sc.SetPersistentPointer(n_FF::p_Ptr::FFEventsToDraw, p_FFEventsToDraw);
	}

#pragma region HTTP Fetch Forex Events
	// Here we only focus on fetching the weeks FF events based on impact/currency
	// Could also filter on today/tomorrow but this data isn't refreshed that often, thus it makes
	// sense to store it all and 'roll' through it in the processing loop later on
	// At least it makes sense for now :)
	// HTTP Request Start
	// Sierra Reference:
	// https://www.sierrachart.com/index.php?page=doc/ACSIL_Members_Functions.html#scMakeHTTPRequest
	enum { REQUEST_NOT_SENT = 0, REQUEST_SENT, REQUEST_RECEIVED }; // status codes
	int& RequestState = sc.GetPersistentInt(n_FF::p_Int::RequestState); // latest request status

	// Only run on full recalc or if update interval has passed
	if (
		sc.Index == 0 ||
		CurrentDateTime.GetTimeInSeconds() > (LastFFUpdate.GetTimeInSeconds() + (60 * sc.Input[n_FF::Input::FFUpdateIntervalInMinutes].GetInt()) + RandomSecond)
		)
	{
		if (RequestState == REQUEST_NOT_SENT)
		{
			if (!sc.MakeHTTPRequest("https://nfs.faireconomy.media/ff_calendar_thisweek.json"))
			{
				if (sc.Input[n_FF::Input::ShowLogMessages].GetYesNo())
					sc.AddMessageToLog("Forex Factory Events: Error Making HTTP Request", 0);
				RequestState = REQUEST_NOT_SENT;
			}
			else
				RequestState = REQUEST_SENT;
		}
	}

	if (RequestState == REQUEST_SENT && sc.HTTPResponse != "")
	{
		// If re-loading data, then clear if previous data exists...
		if (p_FFEvents != NULL)
			p_FFEvents->clear();

		RequestState = REQUEST_RECEIVED;
		HttpResponseContent = sc.HTTPResponse;
		if (sc.Input[n_FF::Input::ShowLogMessages].GetYesNo())
			sc.AddMessageToLog(sc.HTTPResponse, 0);
		std::string JsonEventsString = sc.HTTPResponse;
		auto j = json::parse(JsonEventsString);
		for (auto& elem : j)
		{
			std::string Title = elem["title"];
			std::string Country = elem["country"];
			std::string Date = elem["date"];
			std::string Impact = elem["impact"];
			std::string Forecast = elem["forecast"];
			std::string Previous = elem["previous"];

			// For the date, SC doesn't have a native parser I'm aware of, so we use sscanf to pull out the values
			// individually for year, month, day, etc...
			// Not currently using utc offset for anything
			// Example Format: 2022-05-22T19:01:00-04:00
			// https://stackoverflow.com/questions/26895428/how-do-i-parse-an-iso-8601-date-with-optional-milliseconds-to-a-struct-tm-in-c
			int Year, Month, Day, Hour, Minute, Second, UTCOffsetHour, UTCOffsetMinute = 0;
			sscanf(Date.c_str(), "%d-%d-%dT%d:%d:%d-%d:%d", &Year, &Month, &Day, &Hour, &Minute, &Second, &UTCOffsetHour, &UTCOffsetMinute);

			// Now after we have the year, month, day etc... extracted, we load them into an SCDateTime variable
			// https://www.sierrachart.com/index.php?page=doc/ACSIL_Members_Functions.html#scDateTimeToString
			// https://www.sierrachart.com/SupportBoard.php?ThreadID=18682
			SCDateTime FFEventDateTime;
			FFEventDateTime.SetDateTimeYMDHMS(Year, Month, Day, Hour, Minute, Second);

			// Convert time to chart time zone
			// Assumption is chart time zone is set to local time zone
			// May need to look into this further. When doing compares for events
			// the event time needs to be converted to system time (ie, chart time)
			// But if a chart is a one off and set to alternate time zone then will be an issue
			// as alerts are compared against system time
			// FF Events are using New York Time
			SCDateTime EventDateTime = sc.ConvertDateTimeToChartTimeZone(FFEventDateTime, TIMEZONE_NEW_YORK);
			int EventDay = EventDateTime.GetDay();
			int EventHour = EventDateTime.GetHour();
			int EventMinute = EventDateTime.GetMinute();

			// Initial pre-filtering based on what user has selected for Currency and Impact Levels
			// Skip events that don't match currency filter
			auto it = find(p_Currencies->begin(), p_Currencies->end(), Country.c_str()) != p_Currencies->end();
			if (!it)
				continue;

			// Skip events that don't match impact filter
			it = find(p_ExpectedImpact->begin(), p_ExpectedImpact->end(), Impact.c_str()) != p_ExpectedImpact->end();
			if (!it)
				continue;

			// Now we have the data we need but in std::string type, but our struct is SCString
			// Need to convertusing c_str(), Is there a better way?
			// Convert std::string to SCString
			// https://www.sierrachart.com/SupportBoard.php?ThreadID=55783
			// https://www.cplusplus.com/reference/string/string/c_str/
			FFEvent TmpFFEvent = {
				Title.c_str(),
				Country.c_str(),
				EventDateTime,
				Impact.c_str(),
				Forecast.c_str(),
				Previous.c_str(),
			};

			// Finally, add the FFEvent to the end of the array of events
			p_FFEvents->insert(p_FFEvents->end(), TmpFFEvent);
		}
		// We FF events, now update FFUpdateInterval
		LastFFUpdate = GetNow(sc);
	}
	else if (RequestState == REQUEST_SENT && sc.HTTPResponse == "")
		return;

	// Reset state for next run
	RequestState = REQUEST_NOT_SENT;
#pragma endregion

	// Subgraphs Inital Values
	sc.Subgraph[n_FF::Graph::EventHappeningRightNowExpectedImpactHigh][sc.Index] = 0.0f;
	sc.Subgraph[n_FF::Graph::EventHappeningRightNowExpectedImpactMedium][sc.Index] = 0.0f;
	sc.Subgraph[n_FF::Graph::EventHappeningRightNowExpectedImpactLow][sc.Index] = 0.0f;
	sc.Subgraph[n_FF::Graph::EventHappeningRightNowExpectedImpactNonEconomic][sc.Index] = 0.0f;
	sc.Subgraph[n_FF::Graph::UpcomingEventExpectedImpactHigh][sc.Index] = 0.0f;
	sc.Subgraph[n_FF::Graph::UpcomingEventExpectedImpactMedium][sc.Index] = 0.0f;
	sc.Subgraph[n_FF::Graph::UpcomingEventExpectedImpactLow][sc.Index] = 0.0f;
	sc.Subgraph[n_FF::Graph::UpcomingEventExpectedImpactNonEconomic][sc.Index] = 0.0f;

#pragma region Process Forex Events
	// Here we focus on looping through fetched events and updating fonts/colors/etc...
	// based on user selection and as time passes. Since events were pre-filtered, these
	// are all the vents we want to Draw
	// Events are then pushed to the FFEventsToDraw for later drawing
	if (p_FFEventsToDraw != NULL)
		p_FFEventsToDraw->clear(); // Start with cleared state

	bool b_AddTomorrowHeader = true;
	bool b_AddTodaysEventsHeader = true;
	// Loop through raw FF Events
	for (int i = 0; i < p_FFEvents->size(); i++)
	{
		if (b_AddTodaysEventsHeader && sc.Input[n_FF::Input::ShowTodaysEventsHeader].GetYesNo())
		{
			// Header for Today's Events
			n_FF::FFEventToDraw TodaysEventsHeader = {
				"--- Todays's Events ---",
				sc.Input[n_FF::Input::TodaysEventsHeaderMarkerColor].GetColor(),
				sc.Input[n_FF::Input::TodaysEventsHeaderTextColor].GetColor(),
				sc.Input[n_FF::Input::TodaysEventsHeaderBackgroundColor].GetColor(),
				400,
				false,
				false
			};
			p_FFEventsToDraw->insert(p_FFEventsToDraw->end(), TodaysEventsHeader);
			b_AddTodaysEventsHeader = false;
		}

		// Copy of event to use. See below notes regarding direct reference...
		// TODO: Try this again without making a copy first...
		FFEvent Event = p_FFEvents->at(i);

		// Tmp event to build events to push to EventsToDraw
		n_FF::FFEventToDraw TmpFFEventToDraw;

		// Set the H/M/S from Event
		// Note! This event DateTime has also been converted from NY Time to Chart Time in initial data load
		// For some reason Sierra Complains if you try to use the Event.date.GetDay() directly in the compare statements
		// TODO: Need to test again and see if still the case
		int EventDay = Event.date.GetDay();
		int EventHour = Event.date.GetHour();
		int EventMinute = Event.date.GetMinute();

		// Setup some logic for later use and easier readability
		bool b_EventIsToday = EventDay == CurrentDay;
		bool b_EventIsTomorrow = EventDay == TomorrowDay;
		bool b_EventIsTodayOrTomorrow = b_EventIsToday || b_EventIsTomorrow;
		bool b_ShowTomorrowsEventsStartTime = CurrentDateTime.GetTimeInSeconds() >= sc.Input[n_FF::Input::ShowTomorrowsEventsStartTime].GetTime();

		// Skip event if it's not for today or tomorrow		
		if (!b_EventIsTodayOrTomorrow)
			continue;

		// If this is an event for tommorow but we don't want to show those, skip over it
		if (b_EventIsTomorrow && !sc.Input[n_FF::Input::ShowTomorrowsEvents].GetYesNo())
			continue;

		// If this is an event for tomorrow but not time to show those yet, skip...
		// Otherwise, if event for tomorrow, add the tomorrow header and update the flag to skip header
		// on the next go around
		if (b_EventIsTomorrow && !b_ShowTomorrowsEventsStartTime)
			continue;
		else if (b_EventIsTomorrow && b_AddTomorrowHeader)
		{
			n_FF::FFEventToDraw TomorrowHeader = {
				"--- Tomorrow's Events ---",
				sc.Input[n_FF::Input::TomorrowEventHeaderMarkerColor].GetColor(),
				sc.Input[n_FF::Input::TomorrowEventHeaderTextColor].GetColor(),
				sc.Input[n_FF::Input::TomorrowEventHeaderBackgroundColor].GetColor(),
				400,
				false,
				true
			};
			p_FFEventsToDraw->insert(p_FFEventsToDraw->end(), TomorrowHeader);
			b_AddTomorrowHeader = false; // Reset flag
		}

		// Set Default Text Colors
		TmpFFEventToDraw.EventTextColor = sc.Input[n_FF::Input::EventTextColor].GetColor();
		TmpFFEventToDraw.EventTextBackgroundColor = sc.Input[n_FF::Input::EventTextBackgroundColor].GetColor();

		// Set MarkerColor (Brush) based on High, Medium, Low, Holiday
		COLORREF MarkerColor = RGB(255, 255, 255);
		if (Event.impact == "High")
			TmpFFEventToDraw.MarkerColor = sc.Input[n_FF::Input::ExpectedImpactHighColor].GetColor();
		else if (Event.impact == "Medium")
			TmpFFEventToDraw.MarkerColor = sc.Input[n_FF::Input::ExpectedImpactMediumColor].GetColor();
		else if (Event.impact == "Low")
			TmpFFEventToDraw.MarkerColor = sc.Input[n_FF::Input::ExpectedImpactLowColor].GetColor();
		else if (Event.impact == "Holiday")
			TmpFFEventToDraw.MarkerColor = sc.Input[n_FF::Input::ExpectedImpactNonEconomicColor].GetColor();

		// Construct Event Text and display time in 24hr vs am/pm based on user input
		SCString EventText;
		if (sc.Input[n_FF::Input::TimeFormat].GetInt())
			EventText.Format("%02d:%02d [%s] %s", EventHour, EventMinute, Event.country.GetChars(), Event.title.GetChars());
		else
		{
			if (EventHour == 12)
				EventText.Format("%2d:%02dpm [%s] %s", EventHour, EventMinute, Event.country.GetChars(), Event.title.GetChars());
			else if (EventHour > 12)
				EventText.Format("%2d:%02dpm [%s] %s", EventHour -= 12, EventMinute, Event.country.GetChars(), Event.title.GetChars());
			else
				EventText.Format("%2d:%02dam [%s] %s", EventHour, EventMinute, Event.country.GetChars(), Event.title.GetChars());
		}

		// Are we including Forecast/Previous?
		bool b_ShowForecastAndPrevious = sc.Input[n_FF::Input::ShowForecastAndPrevious].GetYesNo() && Event.forecast != "" && Event.previous != "";
		if (b_ShowForecastAndPrevious)
			EventText.AppendFormat(" [Forecast: %s Previous: %s]", Event.forecast.GetChars(), Event.previous.GetChars());

		// Update event text
		TmpFFEventToDraw.EventText = EventText;

		// TODO: Need to fix this as we are changing these above based on time format
		// For now just reset them as we use to compare current time to event time
		EventDay = Event.date.GetDay();
		EventHour = Event.date.GetHour();
		EventMinute = Event.date.GetMinute();

		// Is this event happening right now based on hour/minute
		// For now it allows the current event to remain in 'Now' status for a minute
		// TODO: Decide if it makes sense to allow user to change this setting to different value
		bool EventHappeningRightNow = false; // Start off as false. Could probably key off the p_EventHappening instead...?
		if (EventHour == CurrentHour && EventMinute == CurrentMinute && !b_EventIsTomorrow)
		{
			// Update Subgraphs
			if (Event.impact == "High")
				sc.Subgraph[n_FF::Graph::EventHappeningRightNowExpectedImpactHigh][sc.Index] = 1.0f;
			else if (Event.impact == "Medium")
				sc.Subgraph[n_FF::Graph::EventHappeningRightNowExpectedImpactMedium][sc.Index] = 1.0f;
			else if (Event.impact == "Low")
				sc.Subgraph[n_FF::Graph::EventHappeningRightNowExpectedImpactLow][sc.Index] = 1.0f;
			else
				sc.Subgraph[n_FF::Graph::EventHappeningRightNowExpectedImpactNonEconomic][sc.Index] = 1.0f;

			// Update Draw data
			if (sc.Input[n_FF::Input::BoldCurrentEvents].GetYesNo())
				TmpFFEventToDraw.FontWeight = 700;
			TmpFFEventToDraw.EventTextColor = sc.Input[n_FF::Input::CurrentEventsTextColor].GetColor();
			TmpFFEventToDraw.EventTextBackgroundColor = sc.Input[n_FF::Input::CurrentEventsBackgroundColor].GetColor();
			EventHappeningRightNow = true;
		}

		// Past Events
		bool b_PastEvent = false;
		if (Event.date < CurrentDateTime && !EventHappeningRightNow)
		{
			TmpFFEventToDraw.EventTextColor = sc.Input[n_FF::Input::PastEventsTextColor].GetColor();
			if (sc.Input[n_FF::Input::StrikeOutPastEvents].GetYesNo())
				TmpFFEventToDraw.StrikeOut = true;
			b_PastEvent = true; // Flag this event as a past event
		}

		// Upcoming Events
		// For now, if event is within 10 minutes coming up
		// TODO: Decide if it makes sense to add input to see how far in advance a user wants this to trigger
		if (Event.date > CurrentDateTime && Event.date.GetTimeInSeconds() < CurrentDateTime.GetTimeInSeconds() + 60 * 10 && !b_EventIsTomorrow)
		{
			if (Event.impact == "High")
				sc.Subgraph[n_FF::Graph::UpcomingEventExpectedImpactHigh][sc.Index] = 1.0f;
			else if (Event.impact == "Medium")
				sc.Subgraph[n_FF::Graph::UpcomingEventExpectedImpactMedium][sc.Index] = 1.0f;
			else if (Event.impact == "Low")
				sc.Subgraph[n_FF::Graph::UpcomingEventExpectedImpactLow][sc.Index] = 1.0f;
			else
				sc.Subgraph[n_FF::Graph::UpcomingEventExpectedImpactNonEconomic][sc.Index] = 1.0f;

			if (sc.Input[n_FF::Input::ItalicUpcomingEvents].GetYesNo())
				TmpFFEventToDraw.Italic = true;

			TmpFFEventToDraw.EventTextColor = sc.Input[n_FF::Input::UpcomingEventsTextColor].GetColor();
			TmpFFEventToDraw.EventTextBackgroundColor = sc.Input[n_FF::Input::UpcomingEventsBackgroundColor].GetColor();
		}

		if (sc.Input[n_FF::Input::HidePastEvents].GetYesNo() && b_PastEvent)
			continue; // Skip loop and don't add event to draw as it's a past event

		// If here, add event to draw later
		p_FFEventsToDraw->insert(p_FFEventsToDraw->end(), TmpFFEventToDraw);

	}
#pragma endregion

	// Draw Events with GDI
	// TODO: Think if we need to call this all the time or not? Same with subgraphs...
	// If time based maybe not, but if tick based then probably so... but for now...
	// Could probably get the type of chart and adjust updates according to time vs tick etc...
	sc.p_GDIFunction = FFDrawToChart;
}

void FFDrawToChart(HWND WindowHandle, HDC DeviceContext, SCStudyInterfaceRef sc)
{
	// Pointer to Struct Array for FF Events to Draw
	std::vector<n_FF::FFEventToDraw>* p_FFEventsToDraw = reinterpret_cast<std::vector<n_FF::FFEventToDraw>*>(sc.GetPersistentPointer(n_FF::p_Ptr::FFEventsToDraw));

	// By default Region 1 is visible but no way to access this via ACSIL
	// Assume it's enabled and offset so we don't draw under it
	int EventSpacing = sc.Input[n_FF::Input::VerticalOffset].GetInt();
	if (sc.Input[n_FF::Input::RegionsVisible].GetYesNo())
		EventSpacing += 22;

	// There are some issues here I need to go back and resolve
	// The updated code to work for OpenGL does not color properly when OpenGL disabled
	// Will have to troubleshoot and figureout why. For now, just left old code in place
	// that will run if OpenGL disabled
	if (sc.IsOpenGLActive())
	{
		// Setup font to use based on chart settings
		SCString ChartFontName;
		int ChartFontSize;
		int ChartFontBold;
		int ChartFontUnderline;
		int ChartFontItalic;

		sc.GetChartFontProperties(ChartFontName, ChartFontSize, ChartFontBold, ChartFontUnderline, ChartFontItalic); // Graphics Settings->Fonts->Chart Text

		// Loop through and process events to draw
		for (int i = 0; i < p_FFEventsToDraw->size(); i++)
		{
			// Setup font based on ChartFont
			n_ACSIL::s_GraphicsFont GraphicsFont;
			GraphicsFont.m_FaceName = ChartFontName;
			// Fontsize based on using default from chart or user value
			int UserFontSize = sc.Input[n_FF::Input::FontSize].GetInt(); // Font size from user input
			GraphicsFont.m_Height = (UserFontSize == 0) ? ChartFontSize : UserFontSize;
			
			// Adjust font based on event setting
			GraphicsFont.m_Weight = p_FFEventsToDraw->at(i).FontWeight; // Weight
			GraphicsFont.m_IsItalic = p_FFEventsToDraw->at(i).Italic; // Italic
			//GraphicsFont.m_IsStrikeOut = p_FFEventsToDraw->at(i).StrikeOut; // StrikeOut - Currently not an option

			sc.Graphics.SetTextFont(GraphicsFont);
			sc.Graphics.SetTextAlign(TA_NOUPDATECP);

			n_ACSIL::s_GraphicsColor EventTextColor;
			EventTextColor.SetColorValue(p_FFEventsToDraw->at(i).EventTextColor);
			sc.Graphics.SetTextColor(EventTextColor);

			n_ACSIL::s_GraphicsColor EventTextColorBackground;
			EventTextColorBackground.SetColorValue(p_FFEventsToDraw->at(i).EventTextBackgroundColor);
			sc.Graphics.SetBackgroundColor(EventTextColorBackground);

			// Increment spacing only after first event
			if (i > 0)
				EventSpacing += sc.Graphics.GetTextHeightWithFont(GraphicsFont) + sc.Input[n_FF::Input::EventSpacingOffset].GetInt();

			// Draw Marker (Rectangle) to the Left of the Event Text
			n_ACSIL::s_GraphicsBrush GraphicsBrush;
			GraphicsBrush.m_BrushType = n_ACSIL::s_GraphicsBrush::BRUSH_TYPE_SOLID;
			GraphicsBrush.m_BrushColor.SetColorValue(p_FFEventsToDraw->at(i).MarkerColor);
			sc.Graphics.SetBrush(GraphicsBrush);

			n_ACSIL::s_GraphicsRectangle EventMarker;
			EventMarker.Left = sc.StudyRegionLeftCoordinate + sc.Input[n_FF::Input::HorizontalOffset].GetInt(); // Left
			EventMarker.Top = sc.StudyRegionTopCoordinate + EventSpacing; // Top
			EventMarker.Right = sc.StudyRegionLeftCoordinate + sc.Input[n_FF::Input::HorizontalOffset].GetInt() + 20; // Right
			EventMarker.Bottom = sc.StudyRegionTopCoordinate + sc.Graphics.GetTextHeightWithFont(GraphicsFont) + EventSpacing; // Bottom
			sc.Graphics.FillRectangle(EventMarker, GraphicsBrush);

			// Draw Text
			sc.Graphics.DrawTextAt(
				p_FFEventsToDraw->at(i).EventText,
				sc.StudyRegionLeftCoordinate + sc.Input[n_FF::Input::HorizontalOffset].GetInt() + 23,
				sc.StudyRegionTopCoordinate + EventSpacing
			);

			// Draw Line to mimic StrikeOut
			// Workaround for now until StrikeOut is supported
			// https://www.sierrachart.com/SupportBoard.php?ThreadID=89107
			if (p_FFEventsToDraw->at(i).StrikeOut)
			{
				int EventMarkerMidPoint = ((EventMarker.Bottom - EventMarker.Top) / 2) + EventMarker.Top;
				n_ACSIL::s_GraphicsSize TextSizeWithFont;
				sc.Graphics.GetTextSizeWithFont(p_FFEventsToDraw->at(i).EventText, GraphicsFont, TextSizeWithFont);
				n_ACSIL::s_GraphicsPen StrikeOutPen;
				StrikeOutPen.m_PenColor.SetColorValue(COLOR_BLACK);
				StrikeOutPen.m_PenStyle = n_ACSIL::s_GraphicsPen::e_PenStyle::PEN_STYLE_SOLID;
				StrikeOutPen.m_Width = 1;
				sc.Graphics.SetPen(StrikeOutPen);
				sc.Graphics.MoveTo(sc.StudyRegionLeftCoordinate + sc.Input[n_FF::Input::HorizontalOffset].GetInt() + 23, EventMarkerMidPoint);
				//sc.Graphics.LineTo(TextSizeWithFont.Width * 1.5, EventMarkerMidPoint); // TODO: Figure out proper line length based on text size/font/etc... this is a hack and doesn't scale
				sc.Graphics.LineTo(TextSizeWithFont.Width, EventMarkerMidPoint); // TODO: Figure out proper line length based on text size/font/etc... this is a hack and doesn't scale

				sc.Graphics.ResetPen();
			}

			sc.Graphics.ResetBrush();
			sc.Graphics.ResetTextFont();
		}
		return;
	}

	// Loop through and process events to draw (Non OpenGL Version)
	for (int i = 0; i < p_FFEventsToDraw->size(); i++)
	{
		// Increment spacing only after first event
		if (i > 0)
			EventSpacing += sc.Input[n_FF::Input::FontSize].GetInt() + sc.Input[n_FF::Input::EventSpacingOffset].GetInt();

		// Draw Marker (Rectangle) to the Left of the Event Text
		HBRUSH Brush = CreateSolidBrush(p_FFEventsToDraw->at(i).MarkerColor);
		// Select the brush into the device context
		HGDIOBJ PriorBrush = SelectObject(DeviceContext, Brush);
		// Draw a rectangle next to event
		Rectangle(DeviceContext,
			sc.StudyRegionLeftCoordinate + sc.Input[n_FF::Input::HorizontalOffset].GetInt(), // Left
			sc.StudyRegionTopCoordinate + EventSpacing, // Top
			sc.StudyRegionLeftCoordinate + sc.Input[n_FF::Input::HorizontalOffset].GetInt() + 20, // Right
			sc.StudyRegionTopCoordinate + sc.Input[n_FF::Input::FontSize].GetInt() + EventSpacing // Bottom
		);

		// Remove the brush from the device context and put the prior brush back in. This is critical!
		SelectObject(DeviceContext, PriorBrush);
		// Delete the brush.  This is critical!  If you do not do this, you will end up with
		// a GDI leak and crash Sierra Chart.
		DeleteObject(Brush);

		// Create font
		HFONT hFont;
		hFont = CreateFont(
			sc.Input[n_FF::Input::FontSize].GetInt(), // Font size from user input
			0,
			0,
			0,
			p_FFEventsToDraw->at(i).FontWeight, // Weight
			p_FFEventsToDraw->at(i).Italic, // Italic
			FALSE, // Underline
			p_FFEventsToDraw->at(i).StrikeOut, // StrikeOut
			DEFAULT_CHARSET,
			OUT_OUTLINE_PRECIS,
			CLIP_DEFAULT_PRECIS,
			CLEARTYPE_QUALITY,
			DEFAULT_PITCH,
			TEXT(sc.ChartTextFont()) // Pulls font used in chart
		);
		SelectObject(DeviceContext, hFont);

		// Set text/colors
		::SetTextAlign(DeviceContext, TA_NOUPDATECP);
		::SetTextColor(DeviceContext, p_FFEventsToDraw->at(i).EventTextColor);
		::SetBkColor(DeviceContext, p_FFEventsToDraw->at(i).EventTextBackgroundColor);

		::TextOut(
			DeviceContext,
			sc.StudyRegionLeftCoordinate + sc.Input[n_FF::Input::HorizontalOffset].GetInt() + 23,
			sc.StudyRegionTopCoordinate + EventSpacing,
			p_FFEventsToDraw->at(i).EventText,
			p_FFEventsToDraw->at(i).EventText.GetLength()
		);
		DeleteObject(hFont);
	}
	return;
}
#pragma endregion